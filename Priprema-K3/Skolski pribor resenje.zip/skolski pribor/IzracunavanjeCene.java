package skolskiPriborJava;

public interface IzracunavanjeCene {
	
	public boolean akcijskaCena(double procenat);

}
